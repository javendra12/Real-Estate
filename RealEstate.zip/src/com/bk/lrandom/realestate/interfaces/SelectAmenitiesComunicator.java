package com.bk.lrandom.realestate.interfaces;

import java.util.ArrayList;

import com.bk.lrandom.realestate.models.Amenities;

public interface SelectAmenitiesComunicator {
	public void getAmenities(ArrayList<Amenities> amenities);
}
