package com.bk.lrandom.realestate.interfaces;

public interface ProfileComunicator {
	public void logout();
}
