package com.google.maps.android.ui;

/**
 * Use {@link IconGenerator} instead.
 */
@Deprecated
public class BubbleIconFactory {
}
